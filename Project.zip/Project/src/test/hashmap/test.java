package test.hashmap;

import java.util.HashMap;
import java.util.Map;

public class test {
    public static void main(String[] args) {

        Map<String,Double> hashMap = new HashMap<>();
        hashMap.put( "K1" , 0.1 );
        hashMap.put( "K2" , 0.2 );
        hashMap.put( "K3" , 0.3 );
        hashMap.put( "K4" , 0.4 );


    }
}
